package dev.autojumpmobile;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.core.BlockPos;
import net.minecraft.world.phys.Vec3;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;

public final class AutoJumpMobile implements ClientModInitializer {
    // Runs once per client tick; no rendering hooks, particles, or background threads.
    private static final double MIN_MOVE_SQUARED = 0.0025;
    private static final double EDGE_CHECK_DISTANCE = 0.72;
    private static final double LANDING_CHECK_DISTANCE = 1.45;

    @Override
    public void onInitializeClient() {
        ClientTickEvents.END_CLIENT_TICK.register(AutoJumpMobile::onClientTick);
    }

    private static void onClientTick(Minecraft client) {
        LocalPlayer player = client.player;
        Level level = client.level;

        if (player == null || level == null || client.screen != null) return;
        if (!player.onGround() || player.isPassenger() || player.isFallFlying()
                || player.isInWater() || player.isInLava() || player.isCrouching()) return;

        Vec3 velocity = player.getDeltaMovement();
        double horizontalSpeedSquared = velocity.x * velocity.x + velocity.z * velocity.z;
        if (horizontalSpeedSquared < MIN_MOVE_SQUARED) return;

        // Use actual horizontal movement direction, including strafing.
        double length = Math.sqrt(horizontalSpeedSquared);
        double dx = velocity.x / length;
        double dz = velocity.z / length;

        BlockPos currentFoot = BlockPos.containing(player.getX(), player.getY() - 0.05, player.getZ());
        if (!hasCollision(level, currentFoot.below())) return;

        BlockPos edgeFoot = BlockPos.containing(
                player.getX() + dx * EDGE_CHECK_DISTANCE,
                player.getY() - 0.05,
                player.getZ() + dz * EDGE_CHECK_DISTANCE
        );

        // Only act if the immediate forward floor is missing.
        if (hasCollision(level, edgeFoot.below())) return;

        // Avoid jumping into a completely empty drop: require a solid landing surface
        // a short distance ahead, so this targets small gaps rather than cliffs.
        BlockPos landingFoot = BlockPos.containing(
                player.getX() + dx * LANDING_CHECK_DISTANCE,
                player.getY() - 0.05,
                player.getZ() + dz * LANDING_CHECK_DISTANCE
        );
        if (!hasCollision(level, landingFoot.below())) return;

        // jumpFromGround() only triggers when grounded; no held key state to get stuck.
        player.jumpFromGround();
    }

    private static boolean hasCollision(Level level, BlockPos pos) {
        BlockState state = level.getBlockState(pos);
        return !state.getCollisionShape(level, pos).isEmpty();
    }
}
