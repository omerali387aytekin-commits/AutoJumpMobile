# AutoJump Mobile

Client-side Fabric mod source for Minecraft Java Edition **1.21.11**.

## Behavior
- Checks once per client tick while the player is moving on the ground.
- If the floor immediately ahead is missing but a landing surface is detected a short distance farther ahead, it triggers a jump.
- Skips menus, crouching, swimming, lava, vehicles, and elytra flight.
- No custom rendering, particles, worker threads, or per-frame rendering code.

## Important limitations
- This is a lightweight starter implementation, not a tested binary. It has not been built or tested against your launcher here.
- It is designed to hop over short gaps, not to blindly jump off cliffs. Block shapes, slabs, stairs, server latency, and unusual terrain can affect detection.
- No mod can guarantee literally zero FPS impact; this avoids rendering work and does only a few block checks per client tick.
- The project uses Mojang mappings for Minecraft 1.21.11. Keep Fabric Loader, Fabric API, and the game on matching versions.

## Build
Requires JDK 21 and internet access for Gradle dependency downloads.

1. Open this folder in IntelliJ IDEA, or install Gradle on a computer.
2. Run `gradle build` from the project directory (or use a Gradle wrapper if you add the standard `gradlew` scripts).
3. The output JAR should appear under `build/libs/` after a successful build.
4. Copy the non-`sources` JAR into the `mods` folder used by your Fabric 1.21.11 profile. Install Fabric API for 1.21.11 too.

The supplied wrapper properties file is included, but the platform-specific `gradlew` launcher scripts are not bundled in this source archive. If building on Android is difficult, compile it on a computer and then transfer the JAR to your launcher.
